/*
Group:
Ridam Jain
Anuraj Kanodia
Abhilash Dodla
Anmol Agarwal
*/
#include <bits/stdc++.h>
#include <armadillo>

using namespace std;
using namespace arma;

#define inLines 35497
#define ROWS 1508
#define COLUMNS 2071

mat A(ROWS,COLUMNS,fill::zeros);

void setData() {
	int i;
	double a,b,d;
	for(i=0; i<inLines; i++) {
		cin >> a >> b >> d;
		A(a-1,b-1) = d;
	}
	return;
}

void setMissing() {
	vector<double> means(A.n_cols);
	int i,j;
	double sum,total;
	double colmean;
	for(i=0; i<A.n_cols; i++) {
		sum = 0; total = 0;
		for(j=0; j<A.n_rows; j++) {
			sum += A(j,i);
			if(A(j,i))
				total++;
		}
		colmean = sum/total;
		if(!colmean)
			continue;
		else {
			for(j=0; j<A.n_rows; j++) {
				if(!A(j,i))
					A(j,i) = colmean;
			}
		}	
	}
	return;
}

int main() {
	int i,j;
	
	setData();
	//setMissing();
	
	mat B = A*A.t();
	
	vec eigval;
	mat eigvec;
	mat U;
	
	eig_sym(eigval,eigvec,B);
	U = fliplr(eigvec);
	
	mat C = A.t()*A;
	mat V;
	
	eig_sym(eigval,eigvec,C);
	V = fliplr(eigvec);
	V = V.t();
	
	eigval = sort(eigval,"descend");
	mat E(U.n_cols,V.n_rows,fill::zeros);
	
	for(i=0;i<eigval.size();i++) {
		E(i,i) = sqrt(eigval[i]);
		if(E(i,i) != E(i,i)) {
			if(E.n_rows>=i)
				E.shed_rows(i,U.n_cols-1);
			if(E.n_cols>=i)
				E.shed_cols(i,V.n_rows-1);
			U.shed_cols(i,U.n_cols-1);
			V.shed_rows(i,V.n_rows-1);
			break;	
		}
	}
	
	U.shed_col(U.n_cols-1);
	V.shed_row(V.n_rows-1);
	E.shed_col(E.n_cols-1);
	E.shed_row(E.n_rows-1);	
	
	mat svd = U*E*V;
	int x = -1;
	
	cout<<"U matrix:"<<endl;
	U.print();
	cout<<endl;
		
	cout<<"E matrix:"<<endl;
	E.print();
	cout<<endl;
		
	cout<<"V transpose matrix:"<<endl;
	V.print();
	cout<<endl;
		
	cout<<"final SVD matrix:"<<endl;
	svd.print();
	cout<<endl;
		
	return 0;
}
