/*
Group:
Ridam Jain
Anuraj Kanodia
Abhilash Dodla
Anmol Agarwal
*/

#include <bits/stdc++.h>
#include <armadillo>

using namespace std;
using namespace arma;

#define r 100
#define c 100
#define inLines 35497
#define ROWS 1508
#define COLUMNS 2071

mat A(ROWS,COLUMNS,fill::zeros);

void setData() {
	int i;
	double a,b,d;
	for(i=0; i<inLines; i++) {
		cin >> a >> b >> d;
		A(a-1,b-1) = d;
	}
	return;
}

void setMissing() {
	vector<double> means(A.n_cols);
	int i,j;
	double sum,total;
	double colmean;
	for(i=0; i<A.n_cols; i++) {
		sum = 0; total = 0;
		for(j=0; j<A.n_rows; j++) {
			sum += A(j,i);
			if(A(j,i))
				total++;
		}
		colmean = sum/total;
		if(!colmean)
			continue;
		else {
			for(j=0; j<A.n_rows; j++) {
				if(!A(j,i))
					A(j,i) = colmean;
			}
		}	
	}
	return;
}

int main() {
	int i,j;
	
	setData();
	//setMissing();

	vector<double> probCols;
	vector<double> probRows;
	
	double allSquares = 0;
	
	for(i=0;i<A.n_rows;i++) {
		for(j=0; j<A.n_cols; j++) {
			allSquares += A(i,j)*A(i,j);
		}
	}
	
	double temp;
	
	for(i=0;i<A.n_cols;i++) {
		temp = 0.0;
		for(j=0; j<A.n_rows; j++) {
			temp += A(j,i)*A(j,i);
		}
		probCols.push_back(temp/allSquares);
	}
	
	for(i=0;i<A.n_rows;i++) {
		temp = 0.0;
		for(j=0; j<A.n_cols; j++) {
			temp += A(i,j)*A(i,j);
		}
		probRows.push_back(temp/allSquares);
	}


	srand(2); //constant seed
	
	vector<int> rowRandNum;
	vector<int> colRandNum;
	
	mat C(A.n_rows,c);
	
	for(i=0 ; i<c; i++) {
		int randCol = rand()%A.n_cols;
		colRandNum.push_back(randCol);
		temp = sqrt(c*probCols[randCol]);
		for(j=0; j< A.n_rows; j++) {
			C(j,i) = A(j,randCol)/temp; 
		}
	}
	
	mat R(r,A.n_cols);
	
	for(i=0 ; i<r; i++) {
		int randRow = rand()%A.n_rows;
		rowRandNum.push_back(randRow);		
		temp = sqrt(r*probRows[randRow]);
		for(j=0; j< A.n_cols; j++) {
			R(i,j) = A(randRow,j)/temp; 
		}
	}

	sort(colRandNum.begin(),colRandNum.end());
	sort(rowRandNum.begin(),rowRandNum.end());
	
	mat W(r,c);
	
	for(i=0 ; i<rowRandNum.size(); i++) {
		for(j=0 ; j<colRandNum.size(); j++) {
			W(i,j) = A(rowRandNum[i],colRandNum[j]);
		}
	}
	
	
	mat U = pinv(W);
	U = fliplr(U);
	

	mat CUR = C*U*R;

	cout<<"C matrix:"<<endl;
	C.print();
	cout<<endl;
		
	cout<<"U matrix:"<<endl;
	U.print();
	cout<<endl;
		
	cout<<"R matrix:"<<endl;
	R.print();
	cout<<endl;
		
	cout<<"final CUR matrix:"<<endl;
	CUR.print();
	cout<<endl;
		
	return 0;
}
