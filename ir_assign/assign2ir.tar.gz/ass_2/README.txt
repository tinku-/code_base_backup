SVD decomposition
Dataset used: FilmTrust (http://www.librec.net/datasets.html)

1.install the reqired package
	sudo apt-get install liblapack-dev
	sudo apt-get install libblas-dev
	sudo apt-get install libboost-dev
	sudo apt-get install libarmadillo-dev

2.link the packages and run compile the code
	g++ SVD.cpp -larmadillo

3.run the compiled file for data set stored in rating.txt
	./a.out < ratings.txt > output.txt

4.output will be generated in output.txt file 
	gedit output.txt




(similarly for )CUR decomposition 
1. install packages 

2.compile
	g++ CUR.cpp -larmadillo

3.run
	./a.out < ratings.txt > output.txt
